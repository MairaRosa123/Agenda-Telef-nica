<?php
include "conexao.php";


$sql = "INSERT INTO listaTelefonica (nome) values ('$nome')";
mysql_query($sql) or die ("Não foi possível inserir os dados");

$sql = "select * from listaTelefonica;";
$query = mysql_query($sql);
while($dados = mysql_fetch_assoc($query)){
    echo $dados["nome"]."<br>";
}

?>