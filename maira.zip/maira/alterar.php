<?php
include "conexao.php";

$sql = "update  listaTelefonica set email ='TESTE@gmail.com' where id = '0000000004'";
mysql_query($sql) or die ("Não foi possível alterar os dados.");

echo "Dados alterados com sucesso";
?>