<?php


$servidor = "localhost:3306";
$usuario = "root";
$senha = "rsp23072002";
$banco = "dataBase";

$conexao = mysql_connect($servidor,$usuario,$senha) or die ("Não foi possivel conectar ao servidor");
mysql_select_db($banco, $conexao) or die ("Nao foi possivel conectar ao banco de dados");



?>
