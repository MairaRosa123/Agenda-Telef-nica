<?php
include "conexao.php";

$sql = "DELETE FROM listaTelefonica where email = 'emailAqui'";
mysql_query($sql) or die ("Não foi possível deletar ");

echo "Dados excluidos com sucesso";

?>